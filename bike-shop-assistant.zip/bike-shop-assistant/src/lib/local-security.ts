export type VoiceRole = "owner" | "manager" | "employee";

export type PinVerifier = {
  salt: string;
  hash: string;
  iterations: number;
};

const PIN_ITERATIONS = 250_000;

function encodeBase64(bytes: Uint8Array): string {
  return btoa(Array.from(bytes, (byte) => String.fromCharCode(byte)).join(""));
}

function decodeBase64(value: string): Uint8Array {
  return Uint8Array.from(atob(value), (character) => character.charCodeAt(0));
}

async function derivePin(pin: string, salt: Uint8Array, iterations: number) {
  if (!globalThis.crypto?.subtle) {
    throw new Error("Secure PIN checking is not available in this browser.");
  }
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(pin),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const saltBuffer = new Uint8Array(salt.length);
  saltBuffer.set(salt);
  return new Uint8Array(
    await crypto.subtle.deriveBits(
      { name: "PBKDF2", hash: "SHA-256", salt: saltBuffer.buffer, iterations },
      key,
      256,
    ),
  );
}

export async function createPinVerifier(pin: string): Promise<PinVerifier> {
  if (!/^\d{4}$/.test(pin)) {
    throw new Error("PIN must be exactly four digits.");
  }
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derivePin(pin, salt, PIN_ITERATIONS);
  return {
    salt: encodeBase64(salt),
    hash: encodeBase64(hash),
    iterations: PIN_ITERATIONS,
  };
}

export async function verifyPin(
  pin: string,
  verifier?: PinVerifier,
): Promise<boolean> {
  if (!verifier || !/^\d{4}$/.test(pin)) return false;
  try {
    const candidate = await derivePin(
      pin,
      decodeBase64(verifier.salt),
      verifier.iterations,
    );
    const expected = decodeBase64(verifier.hash);
    if (candidate.length !== expected.length) return false;
    let difference = 0;
    for (let index = 0; index < candidate.length; index += 1) {
      difference |= candidate[index] ^ expected[index];
    }
    return difference === 0;
  } catch {
    return false;
  }
}

export function canManageStock(role: VoiceRole): boolean {
  return role === "owner" || role === "manager";
}

export function canCreateBills(role: VoiceRole): boolean {
  return role === "owner" || role === "manager";
}

export function canManageVoices(role: VoiceRole): boolean {
  return role === "owner";
}

export function canManageService(role: VoiceRole): boolean {
  return role === "owner" || role === "manager" || role === "employee";
}

export function averageVoiceprints(samples: number[][]): number[] {
  if (!samples.length || samples.some((sample) => sample.length !== samples[0].length)) {
    throw new Error("Voice samples did not match. Please record them again.");
  }
  const averaged = samples[0].map(
    (_, index) =>
      samples.reduce((sum, sample) => sum + sample[index], 0) / samples.length,
  );
  const magnitude = Math.sqrt(
    averaged.reduce((sum, value) => sum + value * value, 0),
  );
  if (!Number.isFinite(magnitude) || magnitude < 1e-8) {
    throw new Error("The voice sample was too quiet. Please try again.");
  }
  return averaged.map((value) => value / magnitude);
}
