export async function captureLocalVoiceprint(
  durationMs = 4000,
): Promise<number[]> {
  if (!navigator.mediaDevices?.getUserMedia) {
    throw new Error("This browser cannot capture a local voice sample.");
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
  });

  try {
    const AudioContextConstructor =
      window.AudioContext ||
      (window as typeof window & { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioContextConstructor) {
      throw new Error("Audio analysis is not supported in this browser.");
    }
    const context = new AudioContextConstructor();
    const analyser = context.createAnalyser();
    analyser.fftSize = 4096;
    analyser.smoothingTimeConstant = 0.6;
    context.createMediaStreamSource(stream).connect(analyser);

    const spectrum = new Float32Array(analyser.frequencyBinCount);
    const bands = Array.from({ length: 14 }, () => 0);
    const sampleCounts = Array.from({ length: 14 }, () => 0);
    const minHz = 80;
    const maxHz = Math.min(3800, context.sampleRate / 2);
    const started = performance.now();

    await new Promise<void>((resolve) => {
      const sample = () => {
        analyser.getFloatFrequencyData(spectrum);
        for (let band = 0; band < bands.length; band += 1) {
          const lowHz = minHz * (maxHz / minHz) ** (band / bands.length);
          const highHz = minHz * (maxHz / minHz) ** ((band + 1) / bands.length);
          const lowBin = Math.max(
            1,
            Math.floor((lowHz * analyser.fftSize) / context.sampleRate),
          );
          const highBin = Math.min(
            spectrum.length,
            Math.ceil((highHz * analyser.fftSize) / context.sampleRate),
          );
          let energy = 0;
          let count = 0;
          for (let bin = lowBin; bin < highBin; bin += 1) {
            const db = spectrum[bin] ?? -120;
            if (Number.isFinite(db) && db > -100) {
              energy += 10 ** (db / 10);
              count += 1;
            }
          }
          if (count) {
            bands[band] += energy / count;
            sampleCounts[band] += 1;
          }
        }
        if (performance.now() - started >= durationMs) {
          resolve();
        } else {
          window.setTimeout(sample, 100);
        }
      };
      sample();
    });

    await context.close();
    const averaged = bands.map((energy, index) =>
      Math.log10(energy / Math.max(sampleCounts[index] ?? 0, 1) + 1e-12),
    );
    const mean = averaged.reduce((sum, value) => sum + value, 0) / averaged.length;
    const centered = averaged.map((value) => value - mean);
    const magnitude = Math.sqrt(
      centered.reduce((sum, value) => sum + value * value, 0),
    );
    if (magnitude < 1e-8) {
      throw new Error("The sample was too quiet. Please try again in a quiet room.");
    }
    return centered.map((value) => value / magnitude);
  } finally {
    stream.getTracks().forEach((track) => track.stop());
  }
}

export function findPossibleVoiceMatch(
  voiceprint: number[],
  profiles: { id: string; name: string; voiceprint?: number[] }[],
): { id: string; name: string; similarity: number } | null {
  let best: { id: string; name: string; similarity: number } | null = null;
  for (const profile of profiles) {
    if (!profile.voiceprint || profile.voiceprint.length !== voiceprint.length) {
      continue;
    }
    const similarity = voiceprint.reduce(
      (sum, value, index) => sum + value * (profile.voiceprint?.[index] ?? 0),
      0,
    );
    if (!best || similarity > best.similarity) {
      best = { id: profile.id, name: profile.name, similarity };
    }
  }
  return best && best.similarity >= 0.86 ? best : null;
}
